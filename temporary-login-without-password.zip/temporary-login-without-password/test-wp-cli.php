<?php
/**
 * Simple test script to verify WP-CLI commands are working
 * 
 * To test, run: wp eval-file test-wp-cli.php
 */

// Test if WP-CLI is available
if ( ! defined( 'WP_CLI' ) || ! WP_CLI ) {
    echo "Error: This script must be run via WP-CLI\n";
    exit( 1 );
}

// Test if our CLI class is loaded
if ( ! class_exists( 'WP_Temporary_Login_CLI' ) ) {
    echo "Error: WP_Temporary_Login_CLI class not found\n";
    exit( 1 );
}

// Test if the common class is available
if ( ! class_exists( 'Wp_Temporary_Login_Without_Password_Common' ) ) {
    echo "Error: Wp_Temporary_Login_Without_Password_Common class not found\n";
    exit( 1 );
}

echo "✅ WP-CLI integration test passed!\n";
echo "📋 Available commands:\n";
echo "- wp tlwp create --email=test@example.com\n";
echo "- wp tlwp list\n";
echo "- wp tlwp delete <user_id>\n";
echo "- wp tlwp disable <user_id>\n";
echo "- wp tlwp enable <user_id>\n";
echo "- wp tlwp url <user_id>\n";
echo "- wp tlwp cleanup\n";
echo "\n🚀 Try running: wp tlwp --help\n";