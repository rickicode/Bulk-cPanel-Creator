# WP-CLI Commands for Temporary Login Without Password

This plugin now supports WP-CLI commands to manage temporary login users from the command line.

## Available Commands

### Create a Temporary User

Create a new temporary login user:

```bash
wp tlwp create --email=test@example.com
```

#### Options:

- `--email=<email>` - Email address for the temporary user (required for regular users)
- `--first_name=<first_name>` - First name (default: "Temp")
- `--last_name=<last_name>` - Last name (default: "User")
- `--role=<role>` - User role (default: "subscriber")
  - Options: administrator, editor, author, contributor, subscriber
- `--expiry=<expiry>` - Expiry time (default: "day")
  - Options: hour, 3_hours, day, 3_days, week, month
- `--redirect_to=<redirect_to>` - Redirect location (default: "wp_dashboard")
  - Options: wp_dashboard, home_page, custom
- `--custom_date=<custom_date>` - Custom expiry date in Y-m-d H:i:s format
- `--max_login_limit=<max_login_limit>` - Maximum login attempts (default: 1)
- `--one_click` - Create a one-click user without email

#### Examples:

```bash
# Create a basic temporary user
wp tlwp create --email=test@example.com

# Create an admin user with custom expiry
wp tlwp create --email=admin@example.com --role=administrator --expiry=week

# Create a one-click temporary user
wp tlwp create --one_click

# Create user with custom settings
wp tlwp create --email=editor@example.com --role=editor --first_name=John --last_name=Doe --expiry=3_days
```

### List Temporary Users

List all temporary login users:

```bash
wp tlwp list
```

#### Options:

- `--format=<format>` - Output format (default: "table")
  - Options: table, csv, json, yaml
- `--status=<status>` - Filter by status (default: "all")
  - Options: active, expired, all

#### Examples:

```bash
# List all temporary users
wp tlwp list

# List only active temporary users
wp tlwp list --status=active

# List in JSON format
wp tlwp list --format=json

# List expired users in CSV format
wp tlwp list --status=expired --format=csv
```

### Delete a Temporary User

Delete a temporary login user:

```bash
wp tlwp delete <user_id>
```

#### Options:

- `--yes` - Skip confirmation prompt

#### Examples:

```bash
# Delete temporary user with ID 123
wp tlwp delete 123

# Delete without confirmation
wp tlwp delete 123 --yes
```

### Disable a Temporary User

Disable a temporary login user (expires immediately):

```bash
wp tlwp disable <user_id>
```

#### Example:

```bash
# Disable temporary user with ID 123
wp tlwp disable 123
```

### Enable a Temporary User

Re-enable a disabled temporary login user:

```bash
wp tlwp enable <user_id>
```

#### Example:

```bash
# Enable temporary user with ID 123
wp tlwp enable 123
```

### Get Login URL

Get the login URL for a temporary user:

```bash
wp tlwp url <user_id>
```

#### Example:

```bash
# Get login URL for temporary user with ID 123
wp tlwp url 123
```

### Cleanup Expired Users

Remove all expired temporary users:

```bash
wp tlwp cleanup
```

#### Options:

- `--dry-run` - Show what would be deleted without actually deleting
- `--yes` - Skip confirmation prompt

#### Examples:

```bash
# Clean up expired users
wp tlwp cleanup

# See what would be cleaned up
wp tlwp cleanup --dry-run

# Cleanup without confirmation
wp tlwp cleanup --yes
```

## Usage Scenarios

### Bulk User Creation

Create multiple temporary users for testing:

```bash
# Create 5 temporary users with different roles
wp tlwp create --email=admin@test.com --role=administrator --expiry=day
wp tlwp create --email=editor@test.com --role=editor --expiry=day
wp tlwp create --email=author@test.com --role=author --expiry=day
wp tlwp create --email=contributor@test.com --role=contributor --expiry=day
wp tlwp create --email=subscriber@test.com --role=subscriber --expiry=day
```

### Automated Cleanup

Set up a cron job to automatically clean up expired users:

```bash
# Add to crontab to run daily at 2 AM
0 2 * * * /usr/local/bin/wp tlwp cleanup --yes --path=/var/www/html
```

### Quick Testing Access

Create a quick admin access for testing:

```bash
wp tlwp create --email=test@example.com --role=administrator --expiry=hour
```

### Monitoring Active Users

Check active temporary users:

```bash
wp tlwp list --status=active --format=table
```

## Error Handling

The WP-CLI commands include proper error handling:

- Email validation for regular users
- Permission checks
- User existence verification
- Proper status messages

## Integration Notes

- Commands are only available when WP-CLI is present
- All existing plugin permissions and settings are respected
- Commands use the same core functionality as the admin interface
- Compatible with multisite installations when run from appropriate context

## Version Requirements

- WordPress with WP-CLI installed
- Temporary Login Without Password plugin version 1.9.2 or higher
- Appropriate user permissions for managing users