<?php
// This page has been disabled
// Redirecting to main settings page
wp_redirect(admin_url('users.php?page=wp-temporary-login-without-password'));
exit;
?>
