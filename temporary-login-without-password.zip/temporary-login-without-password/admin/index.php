<?php
/**
 * Silence is golden.
 *
 * @package    Temporary Login Without Password
 * @since      1.0
 */
