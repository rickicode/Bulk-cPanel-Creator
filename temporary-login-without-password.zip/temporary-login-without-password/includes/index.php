<?php
/**
 * Silence is golden
 *
 * @package Temporary Login Without Password
 */
