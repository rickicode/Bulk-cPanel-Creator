<?php
// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * WP-CLI commands for Temporary Login Without Password plugin
 *
 * @package Temporary Login Without Password
 * @since 1.9.2
 */
class WP_Temporary_Login_CLI {

	/**
	 * Create a temporary login user
	 *
	 * ## OPTIONS
	 *
	 * [--email=<email>]
	 * : Email address for the temporary user
	 *
	 * [--first_name=<first_name>]
	 * : First name for the temporary user
	 * ---
	 * default: Temp
	 * ---
	 *
	 * [--last_name=<last_name>]
	 * : Last name for the temporary user
	 * ---
	 * default: User
	 * ---
	 *
	 * [--role=<role>]
	 * : User role for the temporary user
	 * ---
	 * default: subscriber
	 * options:
	 *   - administrator
	 *   - editor
	 *   - author
	 *   - contributor
	 *   - subscriber
	 * ---
	 *
	 * [--expiry=<expiry>]
	 * : Expiry time for the temporary login
	 * ---
	 * default: day
	 * options:
	 *   - hour
	 *   - 3_hours
	 *   - day
	 *   - 3_days
	 *   - week
	 *   - month
	 * ---
	 *
	 * [--redirect_to=<redirect_to>]
	 * : Where to redirect user after login
	 * ---
	 * default: wp_dashboard
	 * options:
	 *   - wp_dashboard
	 *   - home_page
	 *   - custom
	 * ---
	 *
	 * [--custom_date=<custom_date>]
	 * : Custom expiry date in Y-m-d H:i:s format
	 *
	 * [--max_login_limit=<max_login_limit>]
	 * : Maximum number of times the user can login
	 * ---
	 * default: 1
	 * ---
	 *
	 * [--one_click]
	 * : Create a one-click temporary user (no email required)
	 *
	 * ## EXAMPLES
	 *
	 *     # Create a basic temporary user
	 *     wp tlwp create --email=test@example.com
	 *
	 *     # Create an admin user with custom expiry
	 *     wp tlwp create --email=admin@example.com --role=administrator --expiry=week
	 *
	 *     # Create a one-click temporary user
	 *     wp tlwp create --one_click
	 *
	 * @when after_wp_load
	 */
	public function create( $args, $assoc_args ) {
		// In WP-CLI context, we allow the operation if no user is logged in (CLI execution)
		// or if the current user has manage_options capability
		$current_user_id = get_current_user_id();
		if ( $current_user_id && ! current_user_can( 'manage_options' ) ) {
			$error_response = array(
				'status' => 'error',
				'message' => 'You do not have permission to create temporary logins.'
			);
			WP_CLI::line( json_encode( $error_response ) );
			return;
		}

		$is_one_click = isset( $assoc_args['one_click'] );

		// Prepare user data
		$data = array(
			'user_first_name' => isset( $assoc_args['first_name'] ) ? $assoc_args['first_name'] : 'Temp',
			'user_last_name'  => isset( $assoc_args['last_name'] ) ? $assoc_args['last_name'] : 'User',
			'role'            => isset( $assoc_args['role'] ) ? $assoc_args['role'] : 'subscriber',
			'expiry'          => isset( $assoc_args['expiry'] ) ? $assoc_args['expiry'] : 'day',
			'redirect_to'     => isset( $assoc_args['redirect_to'] ) ? $assoc_args['redirect_to'] : 'wp_dashboard',
			'max_login_limit' => isset( $assoc_args['max_login_limit'] ) ? intval( $assoc_args['max_login_limit'] ) : 1,
			'is_one_click'    => $is_one_click,
		);

		// Handle email validation for non-one-click users
		if ( ! $is_one_click ) {
			if ( empty( $assoc_args['email'] ) ) {
				$error_response = array(
					'status' => 'error',
					'message' => 'Email is required for regular temporary users. Use --one_click for users without email.'
				);
				WP_CLI::line( json_encode( $error_response ) );
				return;
			}

			$email = sanitize_email( $assoc_args['email'] );
			if ( ! is_email( $email ) ) {
				$error_response = array(
					'status' => 'error',
					'message' => 'Invalid email address provided.'
				);
				WP_CLI::line( json_encode( $error_response ) );
				return;
			}

			if ( email_exists( $email ) ) {
				$error_response = array(
					'status' => 'error',
					'message' => 'Email address is already in use.'
				);
				WP_CLI::line( json_encode( $error_response ) );
				return;
			}

			$data['user_email'] = $email;
		} else {
			$data['user_email'] = '';
		}

		// Handle custom date
		if ( isset( $assoc_args['custom_date'] ) ) {
			$data['custom_date'] = $assoc_args['custom_date'];
		}

		// Create user
		$user = Wp_Temporary_Login_Without_Password_Common::create_new_user( $data );

		if ( isset( $user['error'] ) && true === $user['error'] ) {
			$error_response = array(
				'status' => 'error',
				'message' => 'Failed to create temporary user.'
			);
			WP_CLI::line( json_encode( $error_response ) );
			return;
		}

		$user_id = isset( $user['user_id'] ) ? $user['user_id'] : 0;
		if ( ! $user_id ) {
			$error_response = array(
				'status' => 'error',
				'message' => 'User creation failed.'
			);
			WP_CLI::line( json_encode( $error_response ) );
			return;
		}

		// Get login URL
		$login_url = Wp_Temporary_Login_Without_Password_Common::get_login_url( $user_id );
		$user_data = get_userdata( $user_id );
		$expire_time = get_user_meta( $user_id, '_wtlwp_expire', true );

		// Prepare JSON response
		$response = array(
			'status' => 'success',
			'message' => 'Temporary user created successfully',
			'user_id' => $user_id,
			'username' => $user_data->user_login,
			'role' => $data['role'],
			'login_url' => $login_url,
			'expires' => $expire_time ? date( 'Y-m-d H:i:s', $expire_time ) : null,
			'max_login_limit' => $data['max_login_limit']
		);

		// Add email only if it's not a one-click user
		if ( ! $is_one_click ) {
			$response['email'] = $data['user_email'];
		}

		WP_CLI::line( json_encode( $response ) );
	}

	/**
	 * List all temporary login users
	 *
	 * [--format=<format>]
	 * : Render output in a particular format.
	 * ---
	 * default: table
	 * options:
	 *   - table
	 *   - csv
	 *   - json
	 *   - yaml
	 * ---
	 *
	 * [--status=<status>]
	 * : Filter by status
	 * ---
	 * options:
	 *   - active
	 *   - expired
	 *   - all
	 * default: all
	 * ---
	 *
	 * ## EXAMPLES
	 *
	 *     # List all temporary users
	 *     wp tlwp list
	 *
	 *     # List only active temporary users
	 *     wp tlwp list --status=active
	 *
	 *     # List in JSON format
	 *     wp tlwp list --format=json
	 *
	 * @when after_wp_load
	 */
	public function list( $args, $assoc_args ) {
		$status = isset( $assoc_args['status'] ) ? $assoc_args['status'] : 'all';
		$format = isset( $assoc_args['format'] ) ? $assoc_args['format'] : 'table';

		$users = get_users( array(
			'meta_key'   => '_wtlwp_user',
			'meta_value' => true,
			'fields'     => 'all',
		) );

		if ( empty( $users ) ) {
			WP_CLI::warning( 'No temporary login users found.' );
			return;
		}

		$output = array();
		foreach ( $users as $user ) {
			$expire_time = get_user_meta( $user->ID, '_wtlwp_expire', true );
			$is_expired = Wp_Temporary_Login_Without_Password_Common::is_login_expired( $user->ID );
			$user_status = $is_expired ? 'expired' : 'active';

			// Filter by status if specified
			if ( 'all' !== $status && $status !== $user_status ) {
				continue;
			}

			$login_url = '';
			if ( ! $is_expired ) {
				$login_url = Wp_Temporary_Login_Without_Password_Common::get_login_url( $user->ID );
			}

			$output[] = array(
				'ID'          => $user->ID,
				'username'    => $user->user_login,
				'email'       => $user->user_email,
				'role'        => implode( ', ', $user->roles ),
				'status'      => $user_status,
				'expires'     => $expire_time ? date( 'Y-m-d H:i:s', $expire_time ) : 'N/A',
				'login_url'   => $login_url,
			);
		}

		if ( empty( $output ) ) {
			WP_CLI::warning( sprintf( 'No %s temporary login users found.', $status ) );
			return;
		}

		WP_CLI\Utils\format_items( $format, $output, array( 'ID', 'username', 'email', 'role', 'status', 'expires', 'login_url' ) );
	}

	/**
	 * Delete a temporary login user
	 *
	 * <user_id>
	 * : User ID of the temporary user to delete
	 *
	 * [--yes]
	 * : Skip confirmation prompt
	 *
	 * ## EXAMPLES
	 *
	 *     # Delete temporary user with ID 123
	 *     wp tlwp delete 123
	 *
	 *     # Delete without confirmation
	 *     wp tlwp delete 123 --yes
	 *
	 * @when after_wp_load
	 */
	public function delete( $args, $assoc_args ) {
		$user_id = isset( $args[0] ) ? intval( $args[0] ) : 0;

		if ( empty( $user_id ) ) {
			WP_CLI::error( 'User ID is required.' );
			return;
		}

		// Check if user exists
		$user = get_userdata( $user_id );
		if ( ! $user ) {
			WP_CLI::error( 'User not found.' );
			return;
		}

		// Check if it's a temporary user
		if ( ! Wp_Temporary_Login_Without_Password_Common::is_valid_temporary_login( $user_id, false ) ) {
			WP_CLI::error( 'This is not a temporary login user.' );
			return;
		}

		// Confirmation prompt
		if ( ! isset( $assoc_args['yes'] ) ) {
			WP_CLI::confirm( sprintf( 'Are you sure you want to delete temporary user "%s" (ID: %d)?', $user->user_login, $user_id ) );
		}

		// Delete user
		if ( wp_delete_user( $user_id ) ) {
			WP_CLI::success( sprintf( 'Temporary user "%s" (ID: %d) deleted successfully.', $user->user_login, $user_id ) );
		} else {
			WP_CLI::error( 'Failed to delete temporary user.' );
		}
	}

	/**
	 * Disable a temporary login user
	 *
	 * <user_id>
	 * : User ID of the temporary user to disable
	 *
	 * ## EXAMPLES
	 *
	 *     # Disable temporary user with ID 123
	 *     wp tlwp disable 123
	 *
	 * @when after_wp_load
	 */
	public function disable( $args, $assoc_args ) {
		$user_id = isset( $args[0] ) ? intval( $args[0] ) : 0;

		if ( empty( $user_id ) ) {
			WP_CLI::error( 'User ID is required.' );
			return;
		}

		// Check if user exists and is temporary
		if ( ! Wp_Temporary_Login_Without_Password_Common::is_valid_temporary_login( $user_id, false ) ) {
			WP_CLI::error( 'Invalid temporary login user.' );
			return;
		}

		// Disable user
		if ( Wp_Temporary_Login_Without_Password_Common::manage_login( $user_id, 'disable' ) ) {
			$user = get_userdata( $user_id );
			WP_CLI::success( sprintf( 'Temporary user "%s" (ID: %d) disabled successfully.', $user->user_login, $user_id ) );
		} else {
			WP_CLI::error( 'Failed to disable temporary user.' );
		}
	}

	/**
	 * Enable a temporary login user
	 *
	 * <user_id>
	 * : User ID of the temporary user to enable
	 *
	 * ## EXAMPLES
	 *
	 *     # Enable temporary user with ID 123
	 *     wp tlwp enable 123
	 *
	 * @when after_wp_load
	 */
	public function enable( $args, $assoc_args ) {
		$user_id = isset( $args[0] ) ? intval( $args[0] ) : 0;

		if ( empty( $user_id ) ) {
			WP_CLI::error( 'User ID is required.' );
			return;
		}

		// Check if user exists and is temporary
		if ( ! Wp_Temporary_Login_Without_Password_Common::is_valid_temporary_login( $user_id, false ) ) {
			WP_CLI::error( 'Invalid temporary login user.' );
			return;
		}

		// Enable user
		if ( Wp_Temporary_Login_Without_Password_Common::manage_login( $user_id, 'enable' ) ) {
			$user = get_userdata( $user_id );
			WP_CLI::success( sprintf( 'Temporary user "%s" (ID: %d) enabled successfully.', $user->user_login, $user_id ) );
		} else {
			WP_CLI::error( 'Failed to enable temporary user.' );
		}
	}

	/**
	 * Get login URL for a temporary user
	 *
	 * <user_id>
	 * : User ID of the temporary user
	 *
	 * ## EXAMPLES
	 *
	 *     # Get login URL for temporary user with ID 123
	 *     wp tlwp url 123
	 *
	 * @when after_wp_load
	 */
	public function url( $args, $assoc_args ) {
		$user_id = isset( $args[0] ) ? intval( $args[0] ) : 0;

		if ( empty( $user_id ) ) {
			WP_CLI::error( 'User ID is required.' );
			return;
		}

		// Check if user exists and is temporary
		if ( ! Wp_Temporary_Login_Without_Password_Common::is_valid_temporary_login( $user_id, false ) ) {
			WP_CLI::error( 'Invalid temporary login user.' );
			return;
		}

		// Check if user is expired
		if ( Wp_Temporary_Login_Without_Password_Common::is_login_expired( $user_id ) ) {
			WP_CLI::error( 'Temporary user has expired.' );
			return;
		}

		$login_url = Wp_Temporary_Login_Without_Password_Common::get_login_url( $user_id );
		if ( empty( $login_url ) ) {
			WP_CLI::error( 'Failed to get login URL.' );
			return;
		}

		$user = get_userdata( $user_id );
		WP_CLI::line( sprintf( 'Login URL for user "%s" (ID: %d):', $user->user_login, $user_id ) );
		WP_CLI::line( $login_url );
	}

	/**
	 * Clean up expired temporary users
	 *
	 * [--dry-run]
	 * : Show what would be deleted without actually deleting
	 *
	 * [--yes]
	 * : Skip confirmation prompt
	 *
	 * ## EXAMPLES
	 *
	 *     # Clean up expired users
	 *     wp tlwp cleanup
	 *
	 *     # See what would be cleaned up
	 *     wp tlwp cleanup --dry-run
	 *
	 * @when after_wp_load
	 */
	public function cleanup( $args, $assoc_args ) {
		$dry_run = isset( $assoc_args['dry-run'] );

		$users = get_users( array(
			'meta_key'   => '_wtlwp_user',
			'meta_value' => true,
			'fields'     => 'all',
		) );

		if ( empty( $users ) ) {
			WP_CLI::warning( 'No temporary login users found.' );
			return;
		}

		$expired_users = array();
		foreach ( $users as $user ) {
			if ( Wp_Temporary_Login_Without_Password_Common::is_login_expired( $user->ID ) ) {
				$expired_users[] = $user;
			}
		}

		if ( empty( $expired_users ) ) {
			WP_CLI::success( 'No expired temporary users found.' );
			return;
		}

		if ( $dry_run ) {
			WP_CLI::line( sprintf( 'Would delete %d expired temporary users:', count( $expired_users ) ) );
			foreach ( $expired_users as $user ) {
				WP_CLI::line( sprintf( '- %s (ID: %d, Email: %s)', $user->user_login, $user->ID, $user->user_email ) );
			}
			return;
		}

		// Confirmation prompt
		if ( ! isset( $assoc_args['yes'] ) ) {
			WP_CLI::confirm( sprintf( 'Are you sure you want to delete %d expired temporary users?', count( $expired_users ) ) );
		}

		$deleted_count = 0;
		foreach ( $expired_users as $user ) {
			if ( wp_delete_user( $user->ID ) ) {
				$deleted_count++;
				WP_CLI::line( sprintf( 'Deleted: %s (ID: %d)', $user->user_login, $user->ID ) );
			} else {
				WP_CLI::warning( sprintf( 'Failed to delete: %s (ID: %d)', $user->user_login, $user->ID ) );
			}
		}

		WP_CLI::success( sprintf( 'Cleanup completed. Deleted %d of %d expired temporary users.', $deleted_count, count( $expired_users ) ) );
	}
}